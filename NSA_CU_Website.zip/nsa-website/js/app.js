/* ═══════════════════════════════════════════════════════════
   NSA CU — Main JavaScript
   নাঙ্গলকোট স্টুডেন্ট এসোসিয়েশন, চট্টগ্রাম বিশ্ববিদ্যালয়
   ═══════════════════════════════════════════════════════════ */

'use strict';

/* ══════════════════════════════════════
   APP STATE
══════════════════════════════════════ */
const App = {
  config: null,        // loaded from students.json
  students: [],        // working array (may be reordered)
  filtered: [],        // after search/filter
  curView: 'table',    // 'table' | 'card'
  editId: null,        // student id being edited
  sortCol: null,
  sortDir: 'asc',
  femaleUnlocked: false,
  nextId: 100,

  // Drag state
  dragSrc: null,
  dragSrcIdx: null,
};

/* ══════════════════════════════════════
   BOOT
══════════════════════════════════════ */
document.addEventListener('DOMContentLoaded', async () => {
  await loadData();
  buildFilters();
  updateStats();
  doFilter();
  initDragSort();
  initAdminSerialDrag();
  loadSettings();
  applySettings();
  showPage('members');
});

/* ══════════════════════════════════════
   DATA LOAD
══════════════════════════════════════ */
async function loadData() {
  try {
    const res = await fetch('data/students.json');
    const json = await res.json();
    App.config = json.org;
    App.students = json.students.slice().sort((a, b) => a.serial - b.serial);
    App.nextId = Math.max(...App.students.map(s => s.id)) + 1;
    applyOrgSettings();
  } catch(e) {
    console.warn('Could not load JSON, using empty DB:', e);
    App.config = {
      name_bn:'নাঙ্গলকোট স্টুডেন্ট এসোসিয়েশন',
      name_en:'Nangalkot Student Association',
      university_bn:'চট্টগ্রাম বিশ্ববিদ্যালয়',
      short:'NSA • CU',
      tagline:'একতা • শিক্ষা • উন্নয়ন',
      logo_emoji:'🎓',
      established:'২০১৮',
      female_password:'5327'
    };
    App.students = [];
  }
}

/* ══════════════════════════════════════
   SETTINGS (localStorage)
══════════════════════════════════════ */
const SETTINGS_KEY = 'nsa_settings';

function loadSettings() {
  const raw = localStorage.getItem(SETTINGS_KEY);
  if (!raw) return;
  try {
    const s = JSON.parse(raw);
    // Merge into config
    Object.assign(App.config, s);
    applyOrgSettings();
  } catch(e) {}
}

function saveSettings() {
  const s = {
    name_bn:         document.getElementById('s_name_bn')?.value || App.config.name_bn,
    name_en:         document.getElementById('s_name_en')?.value || App.config.name_en,
    university_bn:   document.getElementById('s_univ_bn')?.value || App.config.university_bn,
    short:           document.getElementById('s_short')?.value   || App.config.short,
    tagline:         document.getElementById('s_tagline')?.value || App.config.tagline,
    logo_emoji:      document.getElementById('s_emoji')?.value   || App.config.logo_emoji,
    established:     document.getElementById('s_estd')?.value    || App.config.established,
    female_password: document.getElementById('s_pw')?.value      || App.config.female_password,
  };
  Object.assign(App.config, s);
  localStorage.setItem(SETTINGS_KEY, JSON.stringify(s));
  applySettings();
  toast('✅', 'সেটিংস সংরক্ষণ হয়েছে');
}

function applySettings() {
  applyOrgSettings();
  // Repopulate settings form
  const fields = {
    s_name_bn:  'name_bn', s_name_en: 'name_en',
    s_univ_bn:  'university_bn', s_short: 'short',
    s_tagline:  'tagline', s_emoji: 'logo_emoji',
    s_estd:     'established', s_pw: 'female_password'
  };
  for (const [id, key] of Object.entries(fields)) {
    const el = document.getElementById(id);
    if (el && App.config[key]) el.value = App.config[key];
  }
}

function applyOrgSettings() {
  const c = App.config;
  setText('hdr-title',     c.name_bn);
  setText('hdr-subtitle',  (c.university_bn || '') + ' • ' + (c.name_en || ''));
  setText('hdr-tagline',   c.tagline);
  setText('hdr-emblem',    c.logo_emoji);
  setText('hdr-short',     c.short);
  setText('about-org-name',    c.name_bn);
  setText('about-univ',        c.university_bn);
  setText('about-en-name',     c.name_en);
  setText('about-tagline-txt', c.tagline);
  setText('about-estd',        c.established);
  setText('about-short',       c.short);
}

function setText(id, val) {
  const el = document.getElementById(id);
  if (el && val !== undefined) el.textContent = val;
}

/* ══════════════════════════════════════
   FILTER SETUP
══════════════════════════════════════ */
function buildFilters() {
  const sessions = [...new Set(App.students.map(s => s.session))].sort();
  const depts    = [...new Set(App.students.map(s => s.department))].sort();

  const sf = document.getElementById('fSess');
  const df = document.getElementById('fDept');
  sessions.forEach(v => { const o = new Option(v, v); sf.add(o); });
  depts.forEach(v    => { const o = new Option(v, v); df.add(o); });
}

/* ══════════════════════════════════════
   STATS
══════════════════════════════════════ */
function updateStats() {
  const total  = App.students.length;
  const male   = App.students.filter(s => s.gender === 'male').length;
  const female = App.students.filter(s => s.gender === 'female').length;
  const sess   = new Set(App.students.map(s => s.session)).size;
  const dept   = new Set(App.students.map(s => s.department)).size;

  setText('sc-total',  total);
  setText('sc-male',   male);
  setText('sc-female', female);
  setText('sc-sess',   sess + 'টি');
  setText('sc-dept',   dept + 'টি');
  setText('member-pill', '👥 মোট ' + total + ' জন সদস্য');
}

/* ══════════════════════════════════════
   FILTER + SORT
══════════════════════════════════════ */
function doFilter() {
  const q      = (document.getElementById('searchInput')?.value || '').toLowerCase();
  const fSess  = document.getElementById('fSess')?.value   || '';
  const fDept  = document.getElementById('fDept')?.value   || '';
  const fBlood = document.getElementById('fBlood')?.value  || '';
  const fGend  = document.getElementById('fGender')?.value || '';

  App.filtered = App.students.filter(s =>
    (!q || s.bn.includes(q) || s.en.toLowerCase().includes(q) ||
     s.department.toLowerCase().includes(q) ||
     s.phone.includes(q) || s.address.toLowerCase().includes(q)) &&
    (!fSess  || s.session    === fSess)  &&
    (!fDept  || s.department === fDept)  &&
    (!fBlood || s.blood      === fBlood) &&
    (!fGend  || s.gender     === fGend)
  );

  // Sort
  if (App.sortCol) {
    App.filtered.sort((a, b) => {
      const av = String(a[App.sortCol] || '').toLowerCase();
      const bv = String(b[App.sortCol] || '').toLowerCase();
      return App.sortDir === 'asc' ? av.localeCompare(bv) : bv.localeCompare(av);
    });
  }

  const rt = document.getElementById('resultText');
  if (rt) {
    rt.textContent = App.filtered.length === App.students.length
      ? `মোট ${App.students.length} জন সদস্য দেখাচ্ছে`
      : `${App.filtered.length} জন পাওয়া গেছে — মোট ${App.students.length} জনের মধ্যে`;
  }

  render();
}

/* ══════════════════════════════════════
   SORT (column header click)
══════════════════════════════════════ */
function setSort(col) {
  if (App.sortCol === col) {
    App.sortDir = App.sortDir === 'asc' ? 'desc' : 'asc';
  } else {
    App.sortCol = col;
    App.sortDir = 'asc';
  }
  document.querySelectorAll('thead th').forEach(th => {
    th.classList.remove('sort-asc', 'sort-desc');
    if (th.dataset.col === col) th.classList.add(App.sortDir === 'asc' ? 'sort-asc' : 'sort-desc');
  });
  doFilter();
}

/* ══════════════════════════════════════
   BLOOD CLASS HELPER
══════════════════════════════════════ */
function bCls(b) {
  if (!b) return '';
  if (b.startsWith('AB')) return 'bAB';
  if (b.startsWith('A'))  return 'bA';
  if (b.startsWith('B'))  return 'bB';
  return 'bO';
}

/* ══════════════════════════════════════
   PHONE HTML
══════════════════════════════════════ */
function phoneHTML(s) {
  if (!s.phone) return '<span style="color:var(--c-muted)">—</span>';
  if (s.gender === 'female' && !App.femaleUnlocked) {
    return `<span class="ph-blur" title="পাসওয়ার্ড দিয়ে দেখুন" onclick="openPwModal()">${s.phone}</span>`;
  }
  return `<a class="ph-link" href="tel:${s.phone}">${s.phone}</a>`;
}

/* ══════════════════════════════════════
   RENDER
══════════════════════════════════════ */
function render() {
  if (App.curView === 'table') renderTable();
  else renderCards();
}

/* ── TABLE ── */
function renderTable() {
  const tb = document.getElementById('tblBody');
  if (!tb) return;

  if (!App.filtered.length) {
    tb.innerHTML = `<tr><td colspan="10" style="text-align:center;padding:60px;color:var(--c-muted)">🔍 কোনো সদস্য পাওয়া যায়নি</td></tr>`;
    return;
  }

  tb.innerHTML = App.filtered.map((s, i) => `
    <tr data-id="${s.id}" draggable="true">
      <td><span class="drag-handle" title="টেনে সরান">⠿</span></td>
      <td><span class="row-num">${s.serial}</span></td>
      <td class="cell-name">
        <strong>${s.bn}</strong>
        <small>${s.en}</small>
      </td>
      <td>${s.gender === 'female'
        ? '<span class="g-female">♀ ছাত্রী</span>'
        : '<span class="g-male">♂ ছাত্র</span>'}</td>
      <td><span class="badge-sess">${s.session}</span></td>
      <td>${s.department}</td>
      <td>${phoneHTML(s)}</td>
      <td class="cell-addr">${s.address || '—'}</td>
      <td><span class="badge-blood ${bCls(s.blood)}">${s.blood || '—'}</span></td>
      <td>
        <div class="act-row">
          <button class="act-btn act-edit" onclick="openEdit(${s.id})" title="সম্পাদনা">✏️</button>
          <button class="act-btn act-del"  onclick="delStudent(${s.id})" title="মুছুন">🗑️</button>
        </div>
      </td>
    </tr>
  `).join('');

  initTableDrag();
}

/* ── CARDS ── */
function renderCards() {
  const cg = document.getElementById('cardGrid');
  if (!cg) return;

  if (!App.filtered.length) {
    cg.innerHTML = `<div class="no-res"><div class="nr-ico">🔍</div><p>কোনো সদস্য পাওয়া যায়নি</p></div>`;
    return;
  }

  cg.innerHTML = App.filtered.map(s => {
    const isFem = s.gender === 'female';
    return `
    <div class="s-card" data-id="${s.id}">
      <div class="card-top-bar ${isFem ? 'female' : 'male'}"></div>
      <div class="card-head">
        <div class="avatar ${isFem ? 'av-f' : 'av-m'}">${s.en.trim().charAt(0).toUpperCase()}</div>
        <div class="card-nm">
          <div class="cn">${s.bn}</div>
          <div class="ce">${s.en}</div>
        </div>
        <span class="badge-blood ${bCls(s.blood)}" style="margin-left:auto;flex-shrink:0">${s.blood || '—'}</span>
      </div>
      <div class="card-body">
        <div class="c-row">
          <span class="c-ico">🔢</span>
          <span class="c-lbl">সিরিয়াল</span>
          <span class="c-val"><strong>#${s.serial}</strong></span>
        </div>
        <div class="c-row">
          <span class="c-ico">🎓</span>
          <span class="c-lbl">সেশন</span>
          <span class="c-val"><strong>${s.session}</strong></span>
        </div>
        <div class="c-row">
          <span class="c-ico">📚</span>
          <span class="c-lbl">বিভাগ</span>
          <span class="c-val">${s.department}</span>
        </div>
        <div class="c-row">
          <span class="c-ico">📞</span>
          <span class="c-lbl">ফোন</span>
          <span class="c-val">${phoneHTML(s)}</span>
        </div>
        <div class="c-row">
          <span class="c-ico">📍</span>
          <span class="c-lbl">ঠিকানা</span>
          <span class="c-val" style="font-size:12px;color:var(--c-muted)">${s.address || '—'}</span>
        </div>
      </div>
      <div class="card-foot">
        <span class="g-pill ${isFem ? 'g-pill-f' : 'g-pill-m'}">${isFem ? '♀ ছাত্রী' : '♂ ছাত্র'}</span>
        <div class="act-row">
          <button class="act-btn act-edit" onclick="openEdit(${s.id})">✏️ সম্পাদনা</button>
          <button class="act-btn act-del"  onclick="delStudent(${s.id})">🗑️</button>
        </div>
      </div>
    </div>`;
  }).join('');
}

/* ══════════════════════════════════════
   VIEW SWITCH
══════════════════════════════════════ */
function setView(v) {
  App.curView = v;
  document.getElementById('viewTable').classList.toggle('hidden', v !== 'table');
  document.getElementById('viewCard').classList.toggle('hidden', v !== 'card');
  document.getElementById('vBtnTbl').classList.toggle('active', v === 'table');
  document.getElementById('vBtnCard').classList.toggle('active', v === 'card');
  render();
}

/* ══════════════════════════════════════
   PAGE NAV
══════════════════════════════════════ */
function showPage(id) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-tab').forEach(t => t.classList.remove('active'));

  const pg = document.getElementById('page-' + id);
  const tb = document.getElementById('tab-' + id);
  if (pg) pg.classList.add('active');
  if (tb) tb.classList.add('active');

  // Refresh admin serial list when opening admin
  if (id === 'admin') refreshSerialList();
}

/* ══════════════════════════════════════
   ADMIN SECTIONS
══════════════════════════════════════ */
function showAdminSection(id) {
  document.querySelectorAll('.admin-section').forEach(s => s.classList.remove('active'));
  document.querySelectorAll('.admin-menu-item').forEach(m => m.classList.remove('active'));
  const sec = document.getElementById('asec-' + id);
  const mnu = document.getElementById('amnu-' + id);
  if (sec) sec.classList.add('active');
  if (mnu) mnu.classList.add('active');
  if (id === 'serial') refreshSerialList();
}

/* ══════════════════════════════════════
   STUDENT CRUD
══════════════════════════════════════ */
function openModal(id = null) {
  App.editId = id;
  const isEdit = !!id;
  setText('mTitle', isEdit ? 'সদস্য তথ্য সম্পাদনা করুন' : 'নতুন সদস্য যোগ করুন');
  document.getElementById('mIcon').textContent = isEdit ? '✏️' : '➕';

  if (isEdit) {
    const s = App.students.find(x => x.id === id);
    setVal('f_bn',     s.bn);
    setVal('f_en',     s.en);
    setVal('f_gender', s.gender);
    setVal('f_sess',   s.session);
    setVal('f_blood',  s.blood);
    setVal('f_dept',   s.department);
    setVal('f_phone',  s.phone);
    setVal('f_addr',   s.address);
    setVal('f_serial', s.serial);
  } else {
    ['f_bn','f_en','f_sess','f_dept','f_phone','f_addr'].forEach(id => setVal(id, ''));
    setVal('f_blood', '');
    setVal('f_gender', 'male');
    setVal('f_serial', App.students.length + 1);
  }

  openOverlay('mainModal');
}

function openEdit(id) { openModal(id); }

function saveStudent() {
  const bn     = getVal('f_bn').trim();
  const en     = getVal('f_en').trim();
  const gender = getVal('f_gender');
  const sess   = getVal('f_sess').trim();
  const dept   = getVal('f_dept').trim();
  const phone  = getVal('f_phone').trim();
  const addr   = getVal('f_addr').trim();
  const blood  = getVal('f_blood');
  const serial = parseInt(getVal('f_serial')) || (App.students.length + 1);

  if (!en || !sess || !dept) { toast('❗', 'নাম (ইং), সেশন ও বিভাগ আবশ্যক'); return; }

  if (App.editId) {
    const idx = App.students.findIndex(s => s.id === App.editId);
    App.students[idx] = { ...App.students[idx], bn, en, gender, session:sess, department:dept, phone, address:addr, blood, serial };
    toast('✅', 'সদস্যের তথ্য আপডেট হয়েছে');
  } else {
    App.students.push({ id: App.nextId++, serial, bn, en, gender, session:sess, department:dept, phone, address:addr, blood });
    toast('🎉', 'নতুন সদস্য যোগ হয়েছে');
  }

  closeModal();
  updateStats();
  doFilter();
  refreshSerialList();
}

function delStudent(id) {
  const s = App.students.find(x => x.id === id);
  if (!confirm(`"${s.bn}" কে ডেটাবেস থেকে মুছে ফেলবেন?\nএই কাজ পূর্বাবস্থায় ফেরানো যাবে না।`)) return;
  App.students = App.students.filter(x => x.id !== id);
  updateStats();
  doFilter();
  refreshSerialList();
  toast('🗑️', 'সদস্য মুছে ফেলা হয়েছে');
}

/* ══════════════════════════════════════
   PASSWORD MODAL (female phone)
══════════════════════════════════════ */
function openPwModal() {
  setVal('pwInput', '');
  const em = document.getElementById('pwErrMsg');
  if (em) { em.classList.remove('show'); }
  const pi = document.getElementById('pwInput');
  if (pi) pi.classList.remove('pw-err');
  openOverlay('pwModal');
  setTimeout(() => document.getElementById('pwInput')?.focus(), 100);
}

function checkPassword() {
  const input = getVal('pwInput');
  if (input === App.config.female_password) {
    App.femaleUnlocked = true;
    closeModal();
    render();
    toast('🔓', 'ছাত্রীদের নম্বর দেখা যাচ্ছে');
  } else {
    const pi = document.getElementById('pwInput');
    const em = document.getElementById('pwErrMsg');
    if (pi) { pi.classList.add('pw-err'); setTimeout(() => pi.classList.remove('pw-err'), 500); setVal('pwInput', ''); }
    if (em) em.classList.add('show');
  }
}

function lockFemale() {
  App.femaleUnlocked = false;
  render();
  toast('🔒', 'ছাত্রীদের নম্বর লক করা হয়েছে');
}

/* ══════════════════════════════════════
   SERIAL MANAGER
══════════════════════════════════════ */
function refreshSerialList() {
  const list = document.getElementById('serialList');
  if (!list) return;

  const sorted = [...App.students].sort((a, b) => a.serial - b.serial);

  list.innerHTML = sorted.map((s, i) => `
    <div class="serial-item" data-id="${s.id}" draggable="true">
      <span class="si-handle">⠿</span>
      <span class="si-num">${i + 1}</span>
      <span class="si-name">
        ${s.bn}
        <small> — ${s.en}</small>
      </span>
      <div style="display:flex;gap:6px;align-items:center">
        <button class="act-btn act-edit" style="padding:4px 8px;font-size:12px"
          onclick="moveSerial(${s.id}, -1)" title="উপরে">▲</button>
        <button class="act-btn act-edit" style="padding:4px 8px;font-size:12px"
          onclick="moveSerial(${s.id}, 1)" title="নিচে">▼</button>
        <input type="number" min="1" max="${App.students.length}"
          value="${i + 1}"
          style="width:52px;padding:4px 8px;border:1.5px solid var(--c-border);border-radius:6px;font-size:13px;text-align:center"
          onchange="setSerialDirect(${s.id}, this.value)">
      </div>
    </div>
  `).join('');

  initAdminSerialDrag();
}

function moveSerial(id, dir) {
  const sorted = [...App.students].sort((a, b) => a.serial - b.serial);
  const idx = sorted.findIndex(s => s.id === id);
  const newIdx = idx + dir;
  if (newIdx < 0 || newIdx >= sorted.length) return;

  // Swap serials
  const tmp = sorted[idx].serial;
  sorted[idx].serial = sorted[newIdx].serial;
  sorted[newIdx].serial = tmp;

  // Sync back
  sorted.forEach(s => {
    const orig = App.students.find(x => x.id === s.id);
    if (orig) orig.serial = s.serial;
  });

  doFilter();
  refreshSerialList();
}

function setSerialDirect(id, val) {
  const num = parseInt(val);
  if (isNaN(num) || num < 1) return;
  const s = App.students.find(x => x.id === id);
  if (s) s.serial = num;
  doFilter();
  refreshSerialList();
}

function reorderAllSerials() {
  const sorted = [...App.students].sort((a, b) => a.serial - b.serial);
  sorted.forEach((s, i) => {
    const orig = App.students.find(x => x.id === s.id);
    if (orig) orig.serial = i + 1;
  });
  doFilter();
  refreshSerialList();
  toast('🔢', 'সিরিয়াল পুনরায় সাজানো হয়েছে');
}

/* ══════════════════════════════════════
   DRAG & DROP — Table rows
══════════════════════════════════════ */
function initTableDrag() {
  const rows = document.querySelectorAll('#tblBody tr[data-id]');
  rows.forEach(row => {
    row.addEventListener('dragstart', e => {
      App.dragSrc = row;
      App.dragSrcId = parseInt(row.dataset.id);
      e.dataTransfer.effectAllowed = 'move';
      row.classList.add('dragging');
    });
    row.addEventListener('dragend', () => row.classList.remove('dragging'));
    row.addEventListener('dragover', e => { e.preventDefault(); row.classList.add('drag-over'); });
    row.addEventListener('dragleave', () => row.classList.remove('drag-over'));
    row.addEventListener('drop', e => {
      e.preventDefault();
      row.classList.remove('drag-over');
      const targetId = parseInt(row.dataset.id);
      if (App.dragSrcId === targetId) return;

      const srcS = App.students.find(x => x.id === App.dragSrcId);
      const tgtS = App.students.find(x => x.id === targetId);
      if (srcS && tgtS) {
        const tmp = srcS.serial;
        srcS.serial = tgtS.serial;
        tgtS.serial = tmp;
      }
      doFilter();
    });
  });
}

/* ══════════════════════════════════════
   DRAG & DROP — Admin serial list
══════════════════════════════════════ */
function initAdminSerialDrag() {
  const items = document.querySelectorAll('.serial-item[draggable]');
  items.forEach(item => {
    item.addEventListener('dragstart', e => {
      App.dragSrc = item;
      App.dragSrcId = parseInt(item.dataset.id);
      e.dataTransfer.effectAllowed = 'move';
      item.classList.add('dragging');
    });
    item.addEventListener('dragend', () => item.classList.remove('dragging'));
    item.addEventListener('dragover', e => { e.preventDefault(); item.classList.add('drag-over'); });
    item.addEventListener('dragleave', () => item.classList.remove('drag-over'));
    item.addEventListener('drop', e => {
      e.preventDefault();
      item.classList.remove('drag-over');
      const targetId = parseInt(item.dataset.id);
      if (App.dragSrcId === targetId) return;
      const srcS = App.students.find(x => x.id === App.dragSrcId);
      const tgtS = App.students.find(x => x.id === targetId);
      if (srcS && tgtS) { const tmp = srcS.serial; srcS.serial = tgtS.serial; tgtS.serial = tmp; }
      doFilter();
      refreshSerialList();
    });
  });
}

function initDragSort() {} // placeholder, actual init happens in render

/* ══════════════════════════════════════
   EXPORT
══════════════════════════════════════ */
function doExport() {
  const headers = ['সিরিয়াল','নাম (বাংলা)','নাম (ইংরেজি)','লিঙ্গ','সেশন','বিভাগ','ফোন','ঠিকানা','রক্তের গ্রুপ'];
  const rows = App.filtered
    .slice()
    .sort((a, b) => a.serial - b.serial)
    .map(s => [
      s.serial, s.bn, s.en,
      s.gender === 'female' ? 'ছাত্রী' : 'ছাত্র',
      s.session, s.department, s.phone, s.address, s.blood
    ]);
  const csv = [headers, ...rows].map(r => r.map(c => `"${c}"`).join(',')).join('\n');
  const a = document.createElement('a');
  a.href = 'data:text/csv;charset=utf-8,\uFEFF' + encodeURIComponent(csv);
  a.download = 'NSA_CU_Members.csv';
  a.click();
  toast('⬇️', 'CSV ডাউনলোড শুরু হয়েছে');
}

function doPrint() {
  window.print();
}

/* ══════════════════════════════════════
   MODAL HELPERS
══════════════════════════════════════ */
function openOverlay(id) {
  document.getElementById(id)?.classList.add('open');
}
function closeModal() {
  document.querySelectorAll('.modal-overlay').forEach(o => o.classList.remove('open'));
  App.editId = null;
}

/* ══════════════════════════════════════
   DOM HELPERS
══════════════════════════════════════ */
function getVal(id) {
  return document.getElementById(id)?.value || '';
}
function setVal(id, val) {
  const el = document.getElementById(id);
  if (el) el.value = val ?? '';
}

/* ══════════════════════════════════════
   TOAST
══════════════════════════════════════ */
let toastTimer;
function toast(icon, msg) {
  clearTimeout(toastTimer);
  setText('tIcon', icon);
  setText('tMsg',  msg);
  const t = document.getElementById('toast');
  t.classList.add('show');
  toastTimer = setTimeout(() => t.classList.remove('show'), 3200);
}

/* ══════════════════════════════════════
   GLOBAL EVENT LISTENERS
══════════════════════════════════════ */
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') closeModal();
  if ((e.key === 'Enter') && document.getElementById('pwModal')?.classList.contains('open')) checkPassword();
});

// Close modal on backdrop click
document.querySelectorAll('.modal-overlay').forEach(o => {
  o.addEventListener('click', e => { if (e.target === o) closeModal(); });
});
